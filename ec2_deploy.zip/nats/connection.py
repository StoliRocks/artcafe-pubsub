import json
import asyncio
import logging
from typing import Any, Optional, Dict, List, Callable, Awaitable

import nats
from nats.aio.client import Client as NATS
from nats.js.api import JetStreamContext

from config.settings import settings

logger = logging.getLogger(__name__)


class NatsConnectionManager:
    """NATS connection manager for ArtCafe pub/sub"""
    
    def __init__(self, 
                 servers: Optional[List[str]] = None,
                 connection_options: Optional[Dict[str, Any]] = None):
        """Initialize NATS connection manager"""
        self.servers = servers or settings.NATS_SERVERS
        self.connection_options = connection_options or self._get_default_options()
        self._client: Optional[NATS] = None
        self._js: Optional[JetStreamContext] = None
        self._lock = asyncio.Lock()
        
    def _get_default_options(self) -> Dict[str, Any]:
        """Get default connection options from settings"""
        options = {
            "reconnected_cb": self._reconnected_cb,
            "disconnected_cb": self._disconnected_cb,
            "error_cb": self._error_cb,
            "closed_cb": self._closed_cb,
            "max_reconnect_attempts": -1,  # Unlimited reconnect attempts
            "reconnect_time_wait": 2,  # 2 seconds between reconnect attempts
        }
        
        # Add authentication if configured
        if settings.NATS_USERNAME and settings.NATS_PASSWORD:
            options["user"] = settings.NATS_USERNAME
            options["password"] = settings.NATS_PASSWORD
        elif settings.NATS_TOKEN:
            options["token"] = settings.NATS_TOKEN
            
        # Add TLS if enabled
        if settings.NATS_TLS_ENABLED:
            options["tls"] = {
                "cert_file": settings.NATS_TLS_CERT_PATH,
                "key_file": settings.NATS_TLS_KEY_PATH,
                "ca_file": settings.NATS_TLS_CA_PATH,
            }
            
        return options
        
    async def connect(self) -> NATS:
        """Connect to NATS server"""
        async with self._lock:
            if self._client and self._client.is_connected:
                return self._client
                
            self._client = NATS()
            logger.info(f"Connecting to NATS servers: {self.servers}")
            try:
                await self._client.connect(
                    servers=self.servers,
                    **self.connection_options
                )
                logger.info("Connected to NATS")
                
                # Initialize JetStream
                self._js = self._client.jetstream()
                
                return self._client
            except Exception as e:
                logger.error(f"Error connecting to NATS: {e}")
                self._client = None
                self._js = None
                raise
        
    async def get_jetstream(self) -> JetStreamContext:
        """Get JetStream context"""
        if not self._client or not self._client.is_connected:
            await self.connect()
        return self._js
        
    async def close(self) -> None:
        """Close NATS connection"""
        async with self._lock:
            if self._client and self._client.is_connected:
                await self._client.close()
                self._client = None
                self._js = None
                logger.info("NATS connection closed")
                
    async def publish(self, subject: str, payload: dict) -> None:
        """Publish message to NATS"""
        if not self._client or not self._client.is_connected:
            await self.connect()
            
        payload_bytes = json.dumps(payload).encode("utf-8")
        await self._client.publish(subject, payload_bytes)
        
    async def subscribe(self, 
                      subject: str, 
                      callback: Callable[[nats.aio.msg.Msg], Awaitable[None]],
                      queue: Optional[str] = None) -> nats.aio.Subscription:
        """Subscribe to NATS subject"""
        if not self._client or not self._client.is_connected:
            await self.connect()
            
        return await self._client.subscribe(
            subject=subject,
            cb=callback,
            queue=queue
        )
        
    # Callback handlers
    async def _reconnected_cb(self) -> None:
        """Called when NATS client reconnects"""
        logger.info("Reconnected to NATS server")
        
    async def _disconnected_cb(self) -> None:
        """Called when NATS client disconnects"""
        logger.warning("Disconnected from NATS server")
        
    async def _error_cb(self, e) -> None:
        """Called when NATS client encounters an error"""
        logger.error(f"NATS client error: {e}")
        
    async def _closed_cb(self) -> None:
        """Called when NATS client connection is closed"""
        logger.info("NATS connection closed")

# Singleton instance
nats_manager = NatsConnectionManager()