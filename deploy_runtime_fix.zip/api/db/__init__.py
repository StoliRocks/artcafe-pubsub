from .dynamodb import dynamodb

__all__ = ["dynamodb"]