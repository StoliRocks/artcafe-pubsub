import logging
import secrets
import ulid
from typing import Dict, Optional, List
from datetime import datetime, timedelta

from ..db import dynamodb
from config.settings import settings
from auth import create_access_token
from models import Tenant, TenantCreate
from models.tenant import PaymentStatus, SubscriptionTier

logger = logging.getLogger(__name__)


class TenantService:
    """Service for tenant management"""
    
    async def get_tenant(self, tenant_id: str) -> Optional[Tenant]:
        """
        Get tenant by ID
        
        Args:
            tenant_id: Tenant ID
            
        Returns:
            Tenant or None if not found
        """
        try:
            # Get tenant from DynamoDB
            item = await dynamodb.get_item(
                table_name=settings.TENANT_TABLE_NAME,
                key={"id": tenant_id}
            )
            
            if not item:
                return None
                
            # Convert to Tenant model
            return Tenant(**item)
        except Exception as e:
            logger.error(f"Error getting tenant {tenant_id}: {e}")
            raise
            
    async def create_tenant(self, tenant_data: TenantCreate) -> Dict:
        """
        Create a new tenant
        
        Args:
            tenant_data: Tenant data
            
        Returns:
            Dict with tenant ID, API key, and admin token
        """
        try:
            # Generate tenant ID
            tenant_id = str(ulid.new())
            
            # Generate API key
            api_key = f"art_{secrets.token_urlsafe(32)}"
            
            # Generate admin token
            admin_token_data = {
                "tenant_id": tenant_id,
                "role": "admin",
                "email": tenant_data.admin_email
            }
            admin_token = create_access_token(data=admin_token_data)
            
            # Prepare tenant data
            tenant_dict = tenant_data.dict()
            tenant_dict["id"] = tenant_id
            tenant_dict["status"] = "active"
            tenant_dict["api_key"] = api_key

            # Add payment and subscription information
            trial_days = tenant_dict.pop("trial_days", 14)
            tenant_dict["payment_status"] = PaymentStatus.TRIAL
            tenant_dict["subscription_expires_at"] = (datetime.utcnow() + timedelta(days=trial_days)).isoformat()
            tenant_dict["created_at"] = datetime.utcnow().isoformat()
            tenant_dict["last_payment_date"] = None

            # Set usage limits based on subscription tier
            tier = tenant_dict.get("subscription_tier", SubscriptionTier.BASIC)
            if tier == SubscriptionTier.FREE:
                tenant_dict["max_agents"] = 2
                tenant_dict["max_channels"] = 5
                tenant_dict["max_messages_per_day"] = 500
            elif tier == SubscriptionTier.BASIC:
                tenant_dict["max_agents"] = 5
                tenant_dict["max_channels"] = 10
                tenant_dict["max_messages_per_day"] = 1000
            elif tier == SubscriptionTier.STANDARD:
                tenant_dict["max_agents"] = 15
                tenant_dict["max_channels"] = 25
                tenant_dict["max_messages_per_day"] = 5000
            elif tier == SubscriptionTier.PREMIUM:
                tenant_dict["max_agents"] = 50
                tenant_dict["max_channels"] = 100
                tenant_dict["max_messages_per_day"] = 20000

            # Store in DynamoDB
            await dynamodb.put_item(
                table_name=settings.TENANT_TABLE_NAME,
                item=tenant_dict
            )
            
            # Create initial usage metrics
            await self._initialize_usage_metrics(tenant_id)
            
            return {
                "tenant_id": tenant_id,
                "api_key": api_key,
                "admin_token": admin_token,
                "success": True
            }
        except Exception as e:
            logger.error(f"Error creating tenant: {e}")
            raise
            
    async def _initialize_usage_metrics(self, tenant_id: str) -> None:
        """Initialize usage metrics for a new tenant"""
        today = datetime.utcnow().date().isoformat()

        # Create usage metrics record
        await dynamodb.put_item(
            table_name=settings.USAGE_METRICS_TABLE_NAME,
            item={
                "tenant_id": tenant_id,
                "date": today,
                "messages": 0,
                "api_calls": 0,
                "storage_mb": 0
            }
        )

    async def update_payment_status(
        self,
        tenant_id: str,
        payment_status: str,
        payment_reference: Optional[str] = None
    ) -> Tenant:
        """
        Update tenant payment status

        Args:
            tenant_id: Tenant ID
            payment_status: New payment status
            payment_reference: Optional payment reference

        Returns:
            Updated tenant
        """
        try:
            # Get current tenant data
            tenant = await self.get_tenant(tenant_id)
            if not tenant:
                raise ValueError(f"Tenant {tenant_id} not found")

            # Update payment information
            update_data = {"payment_status": payment_status}

            # Set subscription expiry based on payment status
            if payment_status == PaymentStatus.ACTIVE:
                # Set expiry to 30 days from now for active subscriptions
                update_data["subscription_expires_at"] = (datetime.utcnow() + timedelta(days=30)).isoformat()
                update_data["last_payment_date"] = datetime.utcnow().isoformat()

                if payment_reference:
                    update_data["payment_reference"] = payment_reference

            elif payment_status == PaymentStatus.TRIAL:
                # Set trial expiry to 14 days from now
                update_data["subscription_expires_at"] = (datetime.utcnow() + timedelta(days=14)).isoformat()

            # Update in DynamoDB
            await dynamodb.update_item(
                table_name=settings.TENANT_TABLE_NAME,
                key={"id": tenant_id},
                updates=update_data
            )

            # Get updated tenant
            updated_tenant = await self.get_tenant(tenant_id)
            return updated_tenant

        except Exception as e:
            logger.error(f"Error updating tenant payment status: {e}")
            raise

    async def list_tenants(
        self,
        payment_status: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[Tenant]:
        """
        List tenants with optional filtering

        Args:
            payment_status: Filter by payment status
            limit: Maximum number of tenants to return

        Returns:
            List of tenants
        """
        try:
            # Get tenants from DynamoDB
            # Note: This is a simple scan operation which won't be efficient for large datasets
            # For production, this should be replaced with a proper query using a GSI
            items = await dynamodb.scan(
                table_name=settings.TENANT_TABLE_NAME,
                limit=limit
            )

            # Convert to Tenant models
            tenants = [Tenant(**item) for item in items]

            # Filter by payment status if provided
            if payment_status:
                tenants = [t for t in tenants if t.payment_status == payment_status]

            return tenants

        except Exception as e:
            logger.error(f"Error listing tenants: {e}")
            raise

    async def check_expired_subscriptions(self) -> int:
        """
        Check for expired subscriptions and update their status

        Returns:
            Number of expired subscriptions found and updated
        """
        try:
            now = datetime.utcnow()

            # Get active and trial tenants
            active_tenants = await self.list_tenants()
            expired_count = 0

            # Check each tenant for expiry
            for tenant in active_tenants:
                if (tenant.payment_status in [PaymentStatus.ACTIVE, PaymentStatus.TRIAL] and
                    tenant.subscription_expires_at and
                    tenant.subscription_expires_at < now):

                    # Update to expired status
                    await self.update_payment_status(tenant.tenant_id, PaymentStatus.EXPIRED)
                    expired_count += 1

                    # TODO: Send notification email

            return expired_count

        except Exception as e:
            logger.error(f"Error checking expired subscriptions: {e}")
            raise


# Singleton instance
tenant_service = TenantService()

# Helper function for dependency injection
async def get_tenant(tenant_id: str) -> Optional[Tenant]:
    """Get tenant by ID"""
    return await tenant_service.get_tenant(tenant_id)